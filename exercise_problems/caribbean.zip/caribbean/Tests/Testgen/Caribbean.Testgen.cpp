#include <cstdio>

int main(void)
{
	int numTests = 20;
	int tests[21] = {13, 3, 5, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 19, 21, 22, 23, 25, 27, 29, 30};
	for (int test = 1; test <= numTests; test++)
	{
		char inpName[32];
		sprintf(inpName, "Caribbean.%02d.in", test);
		
		FILE *in = fopen(inpName, "wt");
		fprintf(in, "%d\n", tests[test]);
		fclose(in);
	}
}
