/*
ID: espr1t
LANG: C++
TASK: Caribbean
KEYWORDS: Dynamic Programming
*/

#include <cstdio>
#include <cstring>
#include <cstdlib>

#define MOD 1000003
#define MAX 32

FILE *in; FILE *out;
int dyn[MAX][MAX][MAX][3];

int recurse(int rem0, int rem1, int rem2, int cur)
{
    if (rem0 + rem1 + rem2 == 0)
        return cur != 0;
    if (dyn[rem0][rem1][rem2][cur] != -1)
        return dyn[rem0][rem1][rem2][cur];

    int ans = 0;
    if (cur != 0 && rem0 > 0) ans += rem0 * recurse(rem0 - 1, rem1, rem2, 0);
    if (cur != 1 && rem1 > 0) ans += rem1 * recurse(rem0, rem1 - 1, rem2, 1);
    if (cur != 2 && rem2 > 0) ans += rem2 * recurse(rem0, rem1, rem2 - 1, 2);
    return dyn[rem0][rem1][rem2][cur] = ans % MOD;
}

int main(void)
{
	int numTests = 20;
	for (int test = 1; test <= numTests; test++)
	{
		fprintf(stderr, "Solving test number %d...\n", test);

		char inpFile[32], outFile[32];
		sprintf(inpFile, "Caribbean.%02d.in", test);
		sprintf(outFile, "Caribbean.%02d.sol", test);
		in = fopen(inpFile, "rt"); out = fopen(outFile, "wt");

  	  	memset(dyn, -1, sizeof(dyn));
  	  	int n;
        fscanf(in, "%d", &n);
        fprintf(out, "%d\n", recurse(n - 1, n, n, 0));
		fclose(in); fclose(out);
	}
	fprintf(stderr, "Finished with all tests!\n");
	system("pause");
    return 0;
}
