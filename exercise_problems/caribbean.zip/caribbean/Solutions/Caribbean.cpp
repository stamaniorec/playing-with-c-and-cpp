/*
ID: espr1t
LANG: C++
TASK: Caribbean
KEYWORDS: Dynamic Programming
*/

#include <cstdio>
#include <cstring>

#define MOD 1000003
#define MAX 32

FILE *in; FILE *out;
int dyn[MAX][MAX][MAX][3];

int recurse(int rem0, int rem1, int rem2, int cur)
{
    if (rem0 + rem1 + rem2 == 0)
        return cur != 0;
    if (dyn[rem0][rem1][rem2][cur] != -1)
        return dyn[rem0][rem1][rem2][cur];

    int ans = 0;
    if (cur != 0 && rem0 > 0) ans += rem0 * recurse(rem0 - 1, rem1, rem2, 0);
    if (cur != 1 && rem1 > 0) ans += rem1 * recurse(rem0, rem1 - 1, rem2, 1);
    if (cur != 2 && rem2 > 0) ans += rem2 * recurse(rem0, rem1, rem2 - 1, 2);
    return dyn[rem0][rem1][rem2][cur] = ans % MOD;
}

int main(void)
{
    in = stdin; out = stdout;
//    in = fopen("Caribbean.in", "rt"); out = fopen("Caribbean.out", "wt");

    int n;
    memset(dyn, -1, sizeof(dyn));
    fscanf(in, "%d", &n);
    fprintf(out, "%d\n", recurse(n - 1, n, n, 0));

    return 0;
}
