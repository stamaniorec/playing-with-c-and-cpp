#include <iostream>
#include <list>

#define MAX_N 30
#define NUM_ISLANDS 3
#define MAX_NUM_CITIES NUM_ISLANDS * MAX_N

int result = 0;

// Counts the number of hamiltonian cycles and stores the result in the global variable called result
void hamiltonian_cycle(int adj_m[][MAX_NUM_CITIES], int node, int level, int num_cities, bool visited[])
{
	if(level == num_cities)
	{
		if(adj_m[node][0])
			result = (result+1) % 1000003;
		return;
	}
	for (int i = 0; i < num_cities; i++)
	{
		if(adj_m[node][i] && !visited[i])
		{
			visited[i] = true;
			hamiltonian_cycle(adj_m, i, level+1, num_cities, visited);
			visited[i] = false;

		}
	}
}

int main(int argc, char const *argv[])
{
	int N;
	std::cin >> N;

	int num_cities = NUM_ISLANDS*N;

	// Init adjacency matrix
	int adj_m[MAX_NUM_CITIES][MAX_NUM_CITIES];
	for(int i = 0; i < MAX_NUM_CITIES; ++i)
		for(int j = 0; j < MAX_NUM_CITIES; ++j)
			adj_m[i][j] = 0;

	// Build graph
	for(int island = 0; island < NUM_ISLANDS; ++island)
	{
		for(int city_id = 0; city_id < N; ++city_id)
		{
			for(int other_city = 0; other_city < num_cities; ++other_city)
			{

				if(other_city < island*N || other_city >= (island*N+N))
				{
					adj_m[island*N+city_id][other_city] = 1;
				}
			}
		}
	}

	bool visited[num_cities];
	for(int i = 0; i < num_cities; ++i) visited[i] = false;
	visited[0] = true;

	// Count the number of hamiltonian paths
	// Horrible time complexity but I don't feel like throwing this code away.
	// Only the first 3 or 4 tests take ok amount of time.
	hamiltonian_cycle(adj_m, 0, 1, num_cities, visited);
	std::cout << result << std::endl;

	return 0;
}
