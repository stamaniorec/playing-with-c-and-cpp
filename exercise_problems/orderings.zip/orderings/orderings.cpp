#include <iostream>

int solution(int N, int M)
{
	if(N == 0 && M == 0) return 1;

	int answer = 0;
	if(N > 0)
		answer += solution(N-1, M);
	if(M > 0)
		answer += solution(N, M-1);

	return answer;
}

int main(int argc, char const *argv[])
{	
	int T;
	std::cin >> T;

	int N, M;

	for(int i = 0; i < T; ++i)
	{
		std::cin >> N;
		std::cin >> M;

		std::cout << solution(N, M) << std::endl;
	}
	
	return 0;
}