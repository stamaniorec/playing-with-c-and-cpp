/*
ID: espr1t
LANG: C++
TASK: Orderings
CONTEST: Dean's Cup 2011
KEYWORDS: Easy, Simple Math or Bruteforce
*/

#include <cstdio>
#define MAX 1024
FILE* in; FILE* out;

int main(void)
{
	in = stdin; out = stdout;
//	in = fopen("Orderings.in", "rt"); out = fopen("Orderings.out", "wt");
	
	int numTests;
	fscanf(in, "%d", &numTests);
	for (int test = 0; test < numTests; test++)
	{
		int n, m;
		fscanf(in, "%d %d", &n, &m);
		long long ans = 1;
		for (int i = m + 1; i <= n + m; i++) ans *= i;
		for (int i = 1; i <= n; i++) ans /= i;
		fprintf(out, "%d\n", (int)ans);
	}
	return 0;
}
