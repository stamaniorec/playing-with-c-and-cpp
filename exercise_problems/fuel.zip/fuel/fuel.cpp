#include <iostream>
using namespace std;

int solution(int *A, int N, int K, int L, int cur, int *B)
{
	if(cur == K)
		return 1;
	if(B[cur] != -1)
		return B[cur];

	int ans = 0;
	for(int i = 0; i < N; ++i)
	{
		if(A[i]-cur > L)
			break;

		if(A[i] > cur)
		{
			int res = solution(A, N, K, L, A[i], B) % 1000000007;
			ans = (ans+res) % 1000000007;
			B[A[i]] = res;
		}
	}

	B[cur] = ans;
	return B[cur];
}

int main(int argc, char const *argv[])
{
	int T;
	cin >> T;

	for(int i = 0; i < T; ++i)
	{
		int N, K, L;
		cin >> N >> K >> L;

		int A[N+1];
		for(int j = 0; j < N; ++j)
		{
			cin >> A[j];
		}
		A[N] = K;

		int B[100000];
		for(int j = 0; j < 100000; ++j) B[j] = -1;
		cout << solution(A, N+1, K, L, 0, B) << endl;
	}

	return 0;
}