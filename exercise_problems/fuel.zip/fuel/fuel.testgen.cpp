/*
LANG: C++
TASK: fuel
ID: espr1t
TOUR: Dean's Cup 2009
*/

#include <iostream>
#include <vector>
#include <set>

#define MAX 1024
#define MOD 1000000007

using namespace std;
FILE *in; FILE *out;


int main(void)
{
	out = fopen("fuel.in", "wt");
	
	int numTests = 50;
	int multiplier = 1000 / numTests;
	
	fprintf(out, "%d\n", numTests);
	for (int test = 1; test <= numTests; test++)
	{
		int n = test * multiplier;
		int k = n * 30;
		int l = rand() % k + 1;
		
		fprintf(out, "%d %d %d\n", n, k, l);
		set <int> s;
		while (s.size() < n) s.insert(rand() % (k-1) + 1);
		vector <int> v(s.begin(), s.end());
		for (int i=0; i<(int)v.size(); i++)
			fprintf(out, "%d%c", v[i], i + 1 == v.size() ? '\n' : ' ');
	}
	
	return 0;
}
